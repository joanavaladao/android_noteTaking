package com.example.plainolnotes;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * Created by Joana on 30/04/17.
 */

public class PhotoCursorAdapter extends ArrayAdapter<String> {

    private final List<String> paths;
    private final Context context;
    private static LayoutInflater inflater=null;

    public PhotoCursorAdapter(Context context, List<String> paths) {
        super(context, 0, paths);

        this.paths = paths;
        this.context = context;
    }


    public PhotoCursorAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull List<String> objects) {
        super(context, resource, objects);
        paths = objects;
        this.context = context;
        inflater = ( LayoutInflater )context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    /* How many items to be placed on the list */
    @Override
    public int getCount() {

        if (paths == null){

            return 0;
        }
        return paths.size();
    }

    /* The id of an item that is in a specif position */
    @Override
    public long getItemId(int position) {

        return position;
    }

    /* View to be placed on the list. The information must be provided by the new adapter */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        String path = paths.get(position);

        View rowView;
        rowView = inflater.inflate(R.layout.photo_list_item, null);

        ImageView fieldPhoto = (ImageView) rowView.findViewById(R.id.photo_line_id);
        TextView fieldPath = (TextView) rowView.findViewById(R.id.photo_path);

        if (path != null) {

            try {
                Bitmap bitmap = BitmapFactory.decodeFile(path);
                Bitmap bitmapReduced = Bitmap.createScaledBitmap(bitmap, 300, 300, true);
                fieldPhoto.setImageBitmap(bitmapReduced);
                fieldPhoto.setScaleType(ImageView.ScaleType.FIT_XY);
                fieldPath.setText(path);
            } catch (Exception e) {
                fieldPath.setText("Image "+path+" not found");
            }


//            Toast.makeText(view.getContext(), "imprimiu?", Toast.LENGTH_SHORT).show();
        }

        return rowView;
    }
}
