package com.example.plainolnotes;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

/**
 * Created by Joana on 28/04/17.
 */

public class MyFragmentMap extends SupportMapFragment implements OnMapReadyCallback {

    Double latitude, longitude;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);

        latitude = getArguments().getDouble(EditorActivity.LATITUDE);
        longitude = getArguments().getDouble(EditorActivity.LONGITUDE);
        Log.d("1", "onCreate: map ---> lat = " + latitude + " long = " + longitude);
        getMapAsync(this);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {

        if (latitude != null && longitude != null) {

            LatLng latLong = new LatLng(latitude, longitude);
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLong, 17);
            googleMap.moveCamera(cameraUpdate);

            // adding the pin
            MarkerOptions pin = new MarkerOptions();
            pin.position(latLong);
            googleMap.addMarker(pin);
        } else {
            LatLng latLong = new LatLng(0.0, 0.0);
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLong, 17);
            googleMap.moveCamera(cameraUpdate);
        }
    }
}
