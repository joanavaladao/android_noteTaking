package com.example.plainolnotes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBOpenHelper extends SQLiteOpenHelper{

    //Constants for db name and version
    private static final String DATABASE_NAME = "notes.db";
    private static final int DATABASE_VERSION = 3;

    //Constants for identifying table and columns
    public static final String TABLE_NOTES = "notes";
    public static final String NOTE_ID = "_id";
    public static final String NOTE_TEXT = "noteText";
    public static final String NOTE_TITLE = "noteTitle";
    public static final String NOTE_CREATED = "noteCreated";
    public static final String NOTE_LATITUDE = "noteLatitude";
    public static final String NOTE_LONGITUDE = "noteLongitude";

    public static final String[] ALL_COLUMNS =
            {NOTE_ID, NOTE_TEXT, NOTE_CREATED, NOTE_TITLE, NOTE_LATITUDE, NOTE_LONGITUDE};

    public static final String TABLE_IMAGES = "images";
    public static final String IMAGE_ID = "_id";
    public static final String IMAGE_NOTE_ID = "noteId";
    public static final String IMAGE_PATH = "imagePath";

    public static final String[] IMAGE_COLUMNS =
            {IMAGE_ID, IMAGE_NOTE_ID, IMAGE_PATH};




    //SQL to create table
    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_NOTES + " (" +
                    NOTE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    NOTE_TEXT + " TEXT, " +
                    NOTE_CREATED + " TEXT default CURRENT_TIMESTAMP, " +
                    NOTE_TITLE + " TEXT, " +
                    NOTE_LATITUDE + " REAL, " +
                    NOTE_LONGITUDE + " REAL " +
                    ")";

    public DBOpenHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);

        String sql = "CREATE TABLE " + TABLE_IMAGES + " ("+
                IMAGE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                IMAGE_NOTE_ID + " INTEGER, " +
                IMAGE_PATH + " TEXT, " +
                "FOREIGN KEY(" + IMAGE_NOTE_ID + ") REFERENCES " + TABLE_NOTES + " ("+ NOTE_ID +")) ";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        if (oldVersion < 2){
            // Version 2
            String sql = "ALTER TABLE " + TABLE_NOTES +" ADD COLUMN "+ NOTE_TITLE + " TEXT";
            db.execSQL(sql);
        }

        if (oldVersion < 3){
            // Version 3
            String sql = "ALTER TABLE "+ TABLE_NOTES + " ADD COLUMN " + NOTE_LATITUDE + " REAL";
            db.execSQL(sql);
            sql = "ALTER TABLE "+ TABLE_NOTES + " ADD COLUMN " + NOTE_LONGITUDE + " REAL";
            db.execSQL(sql);

            sql = "CREATE TABLE " + TABLE_IMAGES + " ("+
                    IMAGE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    IMAGE_NOTE_ID + " INTEGER, " +
                    IMAGE_PATH + " TEXT, " +
                    "FOREIGN KEY(" + IMAGE_NOTE_ID + ") REFERENCES " + TABLE_NOTES + " ("+ NOTE_ID +")) ";
            db.execSQL(sql);
        }
    }

}
