package com.example.plainolnotes;

import android.app.Activity;
import android.app.LoaderManager;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class PhotoListActivity extends AppCompatActivity {

    public static final int PHOTO_ACTIVITY = 201;

    // Photo Properties
    int noteID;
    String pathPhoto;
    File filePhoto;
    List<String> photosPaths;

    ListView list;
    public static final int REQUEST_IMAGE_CAPTURE = 567;
    public static final int REQUEST_IMAGE_GALLERY = 568;

    public static final int DETAIL_PHOTO = 250;

    public static final String RETURNING_TYPE = "paths";

    private int positionSelected = -1;

    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (photosPaths != null){
            photosPaths = null;
        }

        // Getting the data from previous activity
        Intent intentNote = getIntent();
        Bundle bundle = intentNote.getExtras();
        photosPaths = bundle.getStringArrayList("photos");

        if (photosPaths == null){
            photosPaths = new ArrayList<String>();
        }

        // Populating the listview
         adapter = new PhotoCursorAdapter(this, R.layout.photo_list_item, photosPaths);

        list = (ListView) findViewById(R.id.list_photo);
        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(PhotoListActivity.this, PhotoActivity.class);
                intent.putExtra("path", photosPaths.get(position));
                positionSelected = position;
                startActivityForResult(intent, DETAIL_PHOTO);
            }
        });

        // Floating buttons (take photo and choose from gallery)
        FloatingActionButton fabCamera = (FloatingActionButton) findViewById(R.id.fab_camera);
        fabCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //initializing properties
                pathPhoto = getExternalFilesDir(null) + "/" + System.currentTimeMillis() + ".jpg";
                filePhoto = new File(pathPhoto);

                Intent intentCamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                intentCamera.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(filePhoto));
                startActivityForResult(intentCamera, REQUEST_IMAGE_CAPTURE);

            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        System.out.println("entrei no activity result");

        if(resultCode == Activity.RESULT_OK){
            switch (requestCode){
                case REQUEST_IMAGE_CAPTURE:
                    if (photosPaths == null) {
                        photosPaths = new ArrayList<String>();
                    }
                    photosPaths.add(pathPhoto);
                    adapter.notifyDataSetChanged();
                    break;
                case DETAIL_PHOTO:
                    String action = data.getStringExtra(PhotoActivity.ACTION);

                    if (action.equals(PhotoActivity.HOME)){
                        positionSelected = -1;
                        int volteiHome = photosPaths.size();
                    } else if (action.equals(PhotoActivity.DELETE)) {
                        photosPaths.remove(positionSelected);
                        positionSelected = -1;
                        adapter.notifyDataSetChanged();
                    }
                    break;
                case REQUEST_IMAGE_GALLERY:
                    try {
                        InputStream inputStream = this.getContentResolver().openInputStream(data.getData());
                    }
                    catch (IOException e){

                    }
                    break;
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            case android.R.id.home:
                ArrayList<String> result = (ArrayList<String>) photosPaths;

                Intent intentReturn = new Intent();
                intentReturn.putStringArrayListExtra(RETURNING_TYPE, result);
                intentReturn.putExtra("teste", "sera que vai?");
                setResult(RESULT_OK, intentReturn);
                finish();
                break;
        }
        return true;
    }
}
