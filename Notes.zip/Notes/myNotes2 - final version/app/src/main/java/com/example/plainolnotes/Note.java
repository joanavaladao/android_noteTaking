package com.example.plainolnotes;

import android.content.ContentValues;
import android.graphics.Bitmap;

import java.util.ArrayList;

/**
 * Created by Joana on 28/04/17.
 */

public class Note {

    private String noteTitle;
    private String noteText;

    private Double latitude;
    private Double longitude;
    private ArrayList<String> photoPath;

    public Note(){
        this.noteTitle = "";
        this.noteText = "";
    }

    public Note(String noteTitle, String noteText) {
        this.noteTitle = noteTitle;
        this.noteText = noteText;
    }

    public Note(String noteTitle, String noteText, Double latitude, Double longitude) {
        this.noteTitle = noteTitle;
        this.noteText = noteText;
        this.latitude = latitude;
        this.longitude = longitude;
        this.photoPath = new ArrayList<String>();
    }

    public String getNoteTitle() {
        return noteTitle;
    }

    public void setNoteTitle(String noteTitle) {
        this.noteTitle = noteTitle;
    }

    public String getNoteText() {
        return noteText;
    }

    public void setNoteText(String noteText) {
        this.noteText = noteText;
    }

    public ArrayList<String> getPhotoPath() {
        return photoPath;
    }

    public void setPhotoPath(ArrayList<String> photoPath) {
        this.photoPath = photoPath;
    }

    public String getPhotoPath(int position){
        if (position >= 0 && position < photoPath.size()){
            return photoPath.get(position);
        } else {
            return null;
        }
    }

    public Boolean addPhotoPath(String path){
        if (!path.isEmpty()){
            if(photoPath == null){
                photoPath = new ArrayList<String>();
            }
            photoPath.add(path);
            return true;
        }
        return false;
    }

    public Boolean removePhotoPath(int position){
        if (position >=0 && position < photoPath.size()){
            photoPath.remove(position);
            return true;
        }
        return false;
    }

    public int findPhotoPath(String path){
        for (int i = 0; i < photoPath.size(); i++){
            if (path.equals(photoPath.get(i))){
                return i;
            }
        }
        return -1;
    }

    public Boolean compareTitle(String title){
        if (this.noteTitle.equals(title)){
            return true;
        }
        return false;
    }

    public Boolean compareText(String text){
        if (this.noteText.equals(text)){
            return true;
        }
        return false;
    }

    public ContentValues getNoteData() {
        ContentValues noteData = new ContentValues();
        noteData.put(DBOpenHelper.NOTE_TITLE, noteTitle);
        noteData.put(DBOpenHelper.NOTE_TEXT, noteText);
        noteData.put(DBOpenHelper.NOTE_LATITUDE, latitude);
        noteData.put(DBOpenHelper.NOTE_LONGITUDE, longitude);

        return noteData;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public int amountOfPaths() {
        if (photoPath == null){
            return 0;
        } else {
            return photoPath.size();
        }
    }

    public void removeAllImages(){
        this.photoPath.clear();
    }


}
