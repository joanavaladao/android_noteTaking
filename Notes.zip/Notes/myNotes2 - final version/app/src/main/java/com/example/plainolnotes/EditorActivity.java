package com.example.plainolnotes;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationServices;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;


public class EditorActivity extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {

    private String action;
    private EditText editor;
    private EditText title;
    private String noteFilter;
    private String photoFilter;
    private Note note;

    // LOCATION
    private GoogleApiClient googleApiClient;
    private Location actualLocation;
    final int MAP = 100;
    final int PHOTO = 200;

    // Interface
    private Boolean enableDelete;

    public static final String LATITUDE = "LATITUDE";
    public static final String LONGITUDE = "LONGITUDE";
    public static final String FILTER = "FILTER";

    private int noteID;

    private Uri photoUri;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);


        editor = (EditText) findViewById(R.id.editText);
        title = (EditText) findViewById(R.id.text_title);

        Intent intent = getIntent();

        Uri uri = intent.getParcelableExtra(NotesProvider.CONTENT_ITEM_TYPE);
        Uri uri2 = intent.getParcelableExtra(PhotoProvider.CONTENT_ITEM_TYPE);
        photoUri = uri2;
        if (uri == null) {
            googleAPI();
            action = Intent.ACTION_INSERT;
            setTitle(getString(R.string.new_note));
            note = new Note();
            if (actualLocation != null){
                note.setLatitude(actualLocation.getLatitude());
                note.setLongitude(actualLocation.getLongitude());
            }
        } else {
            action = Intent.ACTION_EDIT;
            noteFilter = DBOpenHelper.NOTE_ID + "=" + uri.getLastPathSegment();
            photoFilter = DBOpenHelper.IMAGE_NOTE_ID + "=" + uri.getLastPathSegment();
            noteID = Integer.parseInt(uri.getLastPathSegment());
            Cursor cursor = getContentResolver().query(uri,DBOpenHelper.ALL_COLUMNS, noteFilter,null,null);
            cursor.moveToFirst();
            String text = cursor.getString(cursor.getColumnIndex(DBOpenHelper.NOTE_TEXT));
            String title = cursor.getString(cursor.getColumnIndex(DBOpenHelper.NOTE_TITLE));
            Double latitude = cursor.getDouble(cursor.getColumnIndex(DBOpenHelper.NOTE_LATITUDE));
            Double longitude = cursor.getDouble(cursor.getColumnIndex(DBOpenHelper.NOTE_LONGITUDE));
            note = new Note(title, text, latitude, longitude);

            ArrayList<String> notesPaths = dbSearchImages(noteID, this);
            note.setPhotoPath(notesPaths);

        }
        editor.setText(note.getNoteText());
        title.setText(note.getNoteTitle());
        editor.requestFocus();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        if (action.equals(Intent.ACTION_EDIT)) {
            getMenuInflater().inflate(R.menu.menu_editor, menu);
            enableDelete = true;
        } else {
            getMenuInflater().inflate(R.menu.menu_editor, menu);
            enableDelete = false;
        }
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu){
        MenuItem itemDelete = (MenuItem) menu.findItem(R.id.action_delete);
        itemDelete.setVisible(enableDelete);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            case android.R.id.home:
                finishEditing();
                break;
            case R.id.action_delete:
                deleteNote();
                break;
            case R.id.action_map:
                Intent goToMap = new Intent(EditorActivity.this, MapActivity.class);
                Double latitude = note.getLatitude();
                Double longitude = note.getLongitude();
                if (latitude == null || longitude == null ){
                } else {
                    goToMap.putExtra(LATITUDE, latitude);
                    goToMap.putExtra(LONGITUDE, longitude);
                    startActivityForResult(goToMap, MAP);
                }
                break;
            case R.id.action_picture:
                Intent goToPhotos = new Intent(EditorActivity.this, PhotoListActivity.class);
                Bundle photos = new Bundle();
                photos.putStringArrayList("photos", note.getPhotoPath());
                goToPhotos.putExtras(photos);
                startActivityForResult(goToPhotos, PHOTO);
        }

        return true;
    }

    private void finishEditing() {
        String newText = editor.getText().toString().trim();
        String newTitle = title.getText().toString().trim();

        switch (action) {
            case Intent.ACTION_INSERT:
                if (newText.length() == 0 && newTitle.length() == 0) {
                    setResult(RESULT_CANCELED);
                } else {
                    note.setNoteTitle(newTitle);
                    note.setNoteText(newText);
                    insertNote();
                }
                break;
            case Intent.ACTION_EDIT:
                if (newText.length() == 0) {
                    deleteNote();
                } else if (note.compareText(newText) && note.compareTitle(newTitle)) {
                    setResult(RESULT_CANCELED);
                } else {
                    note.setNoteTitle(newTitle);
                    note.setNoteText(newText);
                    updateNote();
                }
        }
        finish();
    }

    private void deleteNote() {

        deleteImage(noteID, this);

        if(true){//delImages) {
            try {
                getContentResolver().delete(NotesProvider.CONTENT_URI, noteFilter, null);
                editor.setText("");
                title.setText("");
                setResult(RESULT_OK);
            }catch (Exception e){
                setResult(RESULT_CANCELED);
            }
        } else {
            setResult(RESULT_CANCELED);
        }
        finish();
    }


    private void updateNote() {
        deleteImage(noteID, this);
          if(true){
            Boolean insResult = insertImage();
            if (insResult){
                ContentValues values = note.getNoteData();
                getContentResolver().update(NotesProvider.CONTENT_URI, values, noteFilter, null);
                setResult(RESULT_OK);
            } else {
                setResult(RESULT_CANCELED);
            }
        } else {
            setResult(RESULT_CANCELED);
        }
    }

    private void insertNote() {
        Uri filter = getContentResolver().insert(NotesProvider.CONTENT_URI, note.getNoteData());
        String filterStr = filter.toString();
        int position = filterStr.indexOf('/');
        String idStr = filterStr.substring(position+1);
        noteID = Integer.parseInt(idStr);
        Boolean result = insertImage();

        setResult(RESULT_OK);
    }

    private Boolean insertImage() {
        try {
            for (String path : note.getPhotoPath()) {
                ContentValues imageData = new ContentValues();
                imageData.put(DBOpenHelper.IMAGE_NOTE_ID, noteID);
                imageData.put(DBOpenHelper.IMAGE_PATH, path);

                getContentResolver().insert(PhotoProvider.CONTENT_URI, imageData);
            }
            return true;
        } catch (Exception e){
            return false;
        }
    }

    @Override
    public void onBackPressed() {
        finishEditing();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == PHOTO){
                List<String> resultList = data.getStringArrayListExtra(PhotoListActivity.RETURNING_TYPE);
                String teste = data.getStringExtra("teste");
                note.setPhotoPath((ArrayList<String>)resultList);
            }
        }
    }

    private void googleAPI(){
        if (googleApiClient == null) {
            googleApiClient = new GoogleApiClient.Builder(EditorActivity.this)
                    .addConnectionCallbacks((GoogleApiClient.ConnectionCallbacks) this)
                    .addOnConnectionFailedListener((GoogleApiClient.OnConnectionFailedListener) this)
                    .addApi(LocationServices.API)
                    .build();
        }

        if (googleApiClient != null){
            googleApiClient.connect();
        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        actualLocation = LocationServices.FusedLocationApi.getLastLocation(googleApiClient);
        if (actualLocation != null) {
            Double actualLatitude = actualLocation.getLatitude();
            Double actualLongitude = actualLocation.getLongitude();
            if (note != null && (note.getLatitude() == null || note.getLongitude() == null)) {
                note.setLatitude(actualLatitude);
                note.setLongitude(actualLongitude);
            }
        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }


    public ArrayList<String> dbSearchImages(int id, Context context) {

        String sql = "SELECT * FROM images WHERE noteID = "+id+";";
        DBOpenHelper helper = new DBOpenHelper(context);
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.rawQuery(sql, null);

        ArrayList<String> imagePaths = new ArrayList<String>();
        while (c.moveToNext()) {
            imagePaths.add(c.getString(c.getColumnIndex(DBOpenHelper.IMAGE_PATH)));
        }

        c.close();
        return imagePaths;
    }

    public void deleteImage(int id, Context context) {

        String sql = "DELETE FROM images WHERE noteID = "+id+";";
        DBOpenHelper helper = new DBOpenHelper(context);
        SQLiteDatabase db = helper.getReadableDatabase();
        db.execSQL(sql);

        db.close();
    }

}
