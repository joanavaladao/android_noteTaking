package com.example.plainolnotes;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

public class PhotoActivity extends AppCompatActivity {

    public static final String ACTION = "ACTION";
    public static final String DELETE = "DELETE";
    public static final String HOME = "HOME";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        Intent pathIntent = getIntent();
        String path = pathIntent.getStringExtra("path");

        ImageView imageView = (ImageView) findViewById(R.id.view_photo);

        if (path != null) {
            try {
                Bitmap bitmap = BitmapFactory.decodeFile(path);
                imageView.setImageBitmap(bitmap);
                imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            } catch (Exception e) {

            }
        }

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentReturn = new Intent();
                intentReturn.putExtra(ACTION, DELETE);
                setResult(RESULT_OK, intentReturn);
                finish();
            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            case android.R.id.home:
                Intent intentReturn = new Intent();
                intentReturn.putExtra(ACTION, HOME);
                setResult(RESULT_OK, intentReturn);
                finish();
                break;
        }

        return true;
    }
}
