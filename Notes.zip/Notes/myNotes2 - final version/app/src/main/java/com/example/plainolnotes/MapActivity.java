package com.example.plainolnotes;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.maps.SupportMapFragment;

public class MapActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent map = getIntent();
        double latitude = map.getDoubleExtra(EditorActivity.LATITUDE, 0.0);
        double longitude = map.getDoubleExtra(EditorActivity.LONGITUDE, 0.0);
        Toast.makeText(this, "lat2 = "+latitude+" long2 = "+longitude, Toast.LENGTH_SHORT).show();

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        MyFragmentMap mapFragment = new MyFragmentMap();
        Bundle location = new Bundle();
        location.putDouble(EditorActivity.LATITUDE, latitude);
        location.putDouble(EditorActivity.LONGITUDE, longitude);
        mapFragment.setArguments(location);
        fragmentTransaction.replace(R.id.fragment_map, mapFragment);
        fragmentTransaction.commit();




        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            case android.R.id.home:
                Intent returnIntent = new Intent();
                setResult(Activity.RESULT_CANCELED, returnIntent);
                finish();
                break;
        }

        return true;
    }


}
